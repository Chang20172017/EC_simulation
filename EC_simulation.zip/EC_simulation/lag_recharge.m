function f=lag_recharge(input, lag)

ndata=length(input);
f=zeros(ndata,1);
for i=1:ndata-1
    temp=input(i);
    f(i+lag)=temp;
end
    