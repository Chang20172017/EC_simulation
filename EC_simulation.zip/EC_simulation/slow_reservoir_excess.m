function f=slow_reservoir_excess(eff_rain, ks, delta_t, h1)

ndata= length(eff_rain);
he=zeros(ndata,1);
f=zeros(ndata,1);

for i=2:ndata
   temp=he(i-1)+eff_rain(i)*delta_t;
   if (temp > h1)
       he(i)=h1/(1+ks*delta_t);
       f(i,1)=ks*he(i);
       f(i,2)=he(i);
       f(i,3)=(temp-h1)/delta_t;
   else
       he(i)=(eff_rain(i)*delta_t+he(i-1))/(1+ks*delta_t);
       f(i,1)=ks*he(i);
       f(i,2)=he(i);
       f(i,3)=0;
   end
end