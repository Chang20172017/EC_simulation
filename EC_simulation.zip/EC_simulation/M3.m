function f=M3(parameters, varargin)
global rainfall weather delta_t discharge  A   tocon

smax=parameters(1); kd=parameters(2); x=parameters(3); ks=parameters(4); kf=parameters(5); Depi=parameters(6);
Dqui=parameters(7); h_old=parameters(8);

h_old=0;
%%  calculate the spring discharge
% calculate the effective rainfall
eff_rain=cal_effrainfall(rainfall, weather, delta_t, smax);
eff_rain=eff_rain/delta_t;
ndata=length(eff_rain);


% calculate epikarst
ff=linear_reservoir(eff_rain, kd, delta_t);

% calculate slow reservoir
slow=linear_reservoir(ff(:,1)*x, ks, delta_t);

% calculate fast reservoir
fast=linear_reservoir(ff(:,1)*(1-x), kf, delta_t);


% calculate the spring discharge
si_discharge=(slow(:,1)+fast(:,1))*A/60;

%% calculate the spring conductivity
in_c=zeros(ndata,1);

% calculate the conductivity in epikarst reservoir
epi_con=linear_dissolve(eff_rain, in_c, ff(:,2), Depi, A, delta_t, tocon);

% calculate the conductivity in fast reservoir
fast_con=linear_dissolve_mix(ff(:,1)*(1-x), epi_con, fast(:,2), Dqui, A, delta_t, h_old, tocon);

% assume the conductivity in slow reservoir always equal to the balanced
% value
slow_con=linspace(tocon,tocon,ndata);

% the spring conductivity is the mix of slow and fast reservoir
spring_con=two_mix(slow(:,1), slow_con, fast(:,1), fast_con);

%% calculate the objectives
mea=discharge; sim(:,1)=si_discharge; sim(:,2)=spring_con;
f=objective_value1(mea,sim);


