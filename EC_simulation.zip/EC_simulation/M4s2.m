function f=M4s2(parameters, varargin)
global rainfall weather delta_t discharge  A   tocon  fff1

smax=parameters(1); kd=parameters(2); h1=parameters(3); ks=parameters(4); kq=parameters(5); 
Depi=parameters(6); Dqui=parameters(7); h_old=parameters(8);


%%  calculate the spring discharge
% calculate the effective rainfall
eff_rain=cal_effrainfall(rainfall, weather, delta_t, smax);
eff_rain=eff_rain/delta_t;
ndata=length(eff_rain);


% calculate the discharge of epikarst
ff=epikarst_reservoir(eff_rain, kd, h1, delta_t);

% calculate the discharge of slow reservoir
slow = linear_reservoir(ff(:,2), ks, delta_t);
% slow=ff(:,2);

% calculate the discharge of fast reservoir
fast = linear_reservoir(ff(:,1)+slow(:,1), kq, delta_t);
% cc=ff(:,1)+slow(:,1);

si_discharge=fast(:,1)*A/60;

%% calculate the spring conductivity
in_c=zeros(ndata,1);

% calculate the conductivity in epikarst reservoir
epi_con=linear_dissolve(eff_rain, in_c, ff(:,3), Depi, A, delta_t, tocon);



for i=1:ndata
    in_slow=slow(:,1);
    in_fast=ff(:,1);
    in_fastcon(i)= (in_slow(i)*tocon+in_fast(i)*epi_con(i))/(in_slow(i)+in_fast(i));
end

% calculate the conductivity in fast reservoir
fast_con=linear_dissolve_mix(in_slow+in_fast, in_fastcon, fast(:,2), Dqui, A, delta_t,h_old, tocon);


spring_con=fast_con;

%% calculate the objectives
mea=discharge; sim(:,1)=si_discharge; sim(:,2)=spring_con;
f=objective_value1(mea,sim);
% f=si_discharge';


