function f=M1(parameters, varargin)
global rainfall weather delta_t discharge  A   tocon

smax=parameters(1); kd=parameters(2);  kp=parameters(3); h1=parameters(4); D=parameters(5); h_old=parameters(6);

h_old=0;
%%  calculate the spring discharge
% calculate the effective rainfall
eff_rain=cal_effrainfall(rainfall, weather, delta_t, smax);
eff_rain=eff_rain/delta_t;
ndata=length(eff_rain);


% calculate the discharge of linear reservoir having two outlets
ff=linear_reservoir_twooutlets(eff_rain, kd, kp, delta_t, h1);

% calculate the spring discharge
si_discharge=(ff(:,1)+ff(:,2))*A/60;


%% calculate the spring conductivity
in_c=zeros(ndata,1);


% calculate the conductivity in epikarst reservoir
spring_con=linear_dissolve_mix(eff_rain, in_c, ff(:,3), D, A, delta_t, h_old, tocon);



%% calculate the objectives
mea=discharge; sim(:,1)=si_discharge; sim(:,2)=spring_con; 

f=objective_value1(mea,sim);


