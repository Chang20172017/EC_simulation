function f=M1(var, parameters, varargin)
% global discharge EC rainfall weather A delta_t tocon rainEC
smax=parameters(1); ks=parameters(2);  kf=parameters(3); h1=parameters(4); Df=parameters(5);  tocon = parameters(6);

 discharge = var{1};  EC = var{2};  rainfall = var{3};  weather = var{4};  A = var{5} ; 
 delta_t = var{6};  rainEC = var{7};

%%  calculate the spring discharge
% calculate the effective rainfall
eff_rain=cal_effrainfall(rainfall, weather, delta_t, smax);
eff_rain=eff_rain/delta_t;
ndata=length(eff_rain);

% % % lag recharge
% eff_rain=lag_recharge(eff_rain, 1);

% calculate the discharge of linear reservoir having two outlets
ff=linear_reservoir_twooutlets(eff_rain, ks, kf, delta_t, h1);

% calculate the spring discharge
si_discharge=(ff(:,1)+ff(:,2))*A/60;


%% calculate the spring conductivity
% considering the lag time for dissolution
in_c=linspace(rainEC, rainEC, ndata);


% calculate the conductivity in epikarst reservoir
spring_con=linear_dissolve_mix(eff_rain, in_c, ff(:,3), Df, A, delta_t, 0, tocon);



%% calculate the objectives
mea(:,1) = discharge; mea(:,2) = EC;
sim(:,1) = si_discharge; sim(:,2)=spring_con; 

f=objective(mea, sim);



