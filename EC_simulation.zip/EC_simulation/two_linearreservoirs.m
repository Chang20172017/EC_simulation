function f = two_linearreservoirs(eff_rain, Kq, Ks, delta_t, h_thre)
%% this  function calculate the total outflow of two parallel reservoirs which corresponding to the quick and slow reservoir
%% the outflow of quick reservoir happens only when the water head in the slow reservoir is higher than h_thre
%% eff_rain is the input(effective rainfall)
%% h_thre is the threshold value for the quick reservoir
%% x is the distribution coefficient
%% Kd is the coefficient of diffuse recharge
%% Kp is the coefficient of point recharge
%% delta_t is the time_step
%% H_thre is the threshold value

%% output f contains two data sets, f(1) is the diffuse recharge, f(2) is the point recharge

%% acquire the data number
ndata=length(eff_rain);
% initialize the reservoir head
hq=zeros(ndata,1);
hs=zeros(ndata,1);
re_q=zeros(ndata,1);
f=zeros(ndata,1);
% x=1;
for i=2:ndata
    temp=hs(i-1)+eff_rain(i)*delta_t;
    if (temp > h_thre)
        re_q(i)=(temp-h_thre)/delta_t;
        hq(i)=(re_q(i)*delta_t+hq(i-1))/(1+Kq*delta_t);
        hs(i)=h_thre/(1+Ks*delta_t);
        f(i,1)=Ks*hs(i);
        f(i,2)=Kq*hq(i);
        f(i,3)=hs(i);
        f(i,4)=hq(i);
    else
        hq(i)=hq(i-1)/(1+Kq*delta_t);
        hs(i)=(eff_rain(i)*delta_t+hs(i-1))/(1+Ks*delta_t);
        f(i,1)=Ks*hs(i);
        f(i,2)=Kq*hq(i);
        f(i,3)=hs(i);
        f(i,4)=hq(i);
    end
end
        
