%% ��ȡģ������
clear; clc;
global discharge  rainfall  weather  A  delta_t  tocon
global AMALGAM_dir EXAMPLE_dir



load data6h.mat

ndata=length(rainfall);


%% 


A=1e06;       %% define the modelling area
delta_t=15*24;
tocon=446.6;

p=cell(12,4);
%% smax, kd, kp, h1, D, h_old
p{1,1}=[0, 1e-07, 1e-04, 0.00, 0, 0]; p{1,2}= [0.2, 1e-03, 1e-01, 0.5, 1, 5]; p{1,3}='M1'; p{1,4}=6; 
p{2,1}=[0, 1e-07, 1e-04, 0.00, 0, 0]; p{2,2}= [0.2, 1e-03, 1e-01, 0.5, 1, 5]; p{2,3}='M1s1'; p{2,4}=6; 
%% smax, kd, kp, h1, D, h_old
p{3,1}=[0, 1e-07, 1e-04, 0, 0, 0]; p{3,2}= [0.2, 1e-03, 1e-01, 0.5, 1, 5]; p{3,3}='M2'; p{3,4}=6; 
p{4,1}=[0, 1e-07, 1e-04, 0, 0, 0]; p{4,2}= [0.2, 1e-03, 1e-01, 0.5, 1, 5]; p{4,3}='M2s1'; p{4,4}=6; 
p{5,1}=[0, 1e-07, 1e-05, 0, 0, 0]; p{5,2}= [0.2, 1e-03, 1e-01, 0.5, 1, 10]; p{5,3}='M2s2'; p{5,4}=6; 
%% smax, kd, x, ks, kf, Depi, Dqui, h_old
p{6,1}=[0, 1e-06, 0, 1e-07,  1e-04, 0, 0, 0]; p{6,2}= [0.2, 1e-1, 1, 1e-04, 1e-01, 1, 1, 1]; p{6,3}='M3'; p{6,4}=8; 
p{7,1}=[0, 1e-06, 0, 1e-07,  1e-04, 0, 0, 0]; p{7,2}= [0.2, 1e-1, 1, 1e-04, 1e-01, 1, 1, 1]; p{7,3}='M3s1'; p{7,4}=8; 
p{8,1}=[0, 1e-06, 0, 1e-07,  1e-04, 0, 0, 0]; p{8,2}= [0.2, 1e-1, 1, 1e-04, 1e-01, 1, 1, 1]; p{8,3}='M3s2'; p{8,4}=8; 
%% smax, kd, h1, ks, kq, Depi, Dqui, h_old 
p{9,1}=[0, 1e-07, 0, 1e-07, 1e-04, 0, 0, 0]; p{9,2}=[0.2, 1e-04, 0.050, 1e-04, 1e-02, 1, 1, 1]; p{9,3}='M4'; p{9,4}=8;
p{10,1}=[0, 1e-07, 0, 1e-07, 1e-04, 0, 0, 0]; p{10,2}=[0.2, 1e-04, 0.055, 1e-04, 1e-02, 1, 1, 1]; p{10,3}='M4s1'; p{10,4}=8;
p{11,1}=[0, 1e-07, 0.0, 1e-07, 1e-04, 0, 0, 0]; p{11,2}=[0.2, 1e-04, 0.065, 1e-04, 1e-02, 1, 1, 1]; p{11,3}='M4s2'; p{11,4}=8;





% %% use SC-SAHEL to calibrate model

% for i=1:11
% 	ObjFun=p{i,3};   
%     MaxFcal=100000;
%     lb=p{i,1}; ub=p{i,2};	
%     [bestx,bestf,misc] = SC_SAHEL(lb,ub,MaxFcal,ObjFun,...
%     'EAs',{'FL','DEF','MCCE','GWO'},'NumOfComplex',8,'Parallel',false,...
%     'ReSamp',true);
%     xxx{i,:}=bestx;
%     fff(i)=bestf;
% end





cd(path2);
AMALGAM_dir = pwd; EXAMPLE_dir = [pwd '\example_6'];

% Add subdirectories to search path
addpath(AMALGAM_dir); addpath(EXAMPLE_dir); addpath([pwd '\postprocessing']);
% Define true Pareto front to be empty  
Fpareto = []; sim = [];
for i=1:11
%define the basic information of AMALGAM
    AMALGAMPar.N = 30;                 % Define population size
    AMALGAMPar.T = 7000;                 % How many generations?
    AMALGAMPar.d = p{i,4};                  % How many parameters?
    AMALGAMPar.m = 2;                   % How many objective functions?
    
    % Define parameter ranges, if 'latin'
    Par_info.initial = 'latin';             % Latin hypercube sampling
    Par_info.boundhandling = 'reflect';       % Explicit boundary handling
    Par_info.min = p{i,1};     % If 'lejopejopgjeriojgioredfkdatin', min values
    Par_info.max = p{i,2};     % If 'latin', max values
    
    % Define name of function
    Func_name =p{i,3};

    % Run the AMALGAM code and obtain non-dominated solution set
     [ X , F , output , Z ] = AMALGAM ( AMALGAMPar , Func_name , Par_info , Fpareto );
    
    cd(path1);
    xxx{i}=X;
    fff{i}=F;
end