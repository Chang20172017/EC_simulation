function f = linear_reservoir_twooutlets(eff_rain, Kd, Kp, delta_t, h_thre)
%% the  epikarst reservoir with a threshold to control the occuring of the point recharge
%% eff_rain is the input(effective rainfall)
%% Kd is the coefficient of diffuse recharge
%% Kp is the coefficient of point recharge
%% delta_t is the time_step
%% H_thre is the threshold value

%% output f contains two data sets, f(1) is the diffuse recharge, f(2) is the point recharge

%% acquire the data number
ndata=length(eff_rain);
% initialize the reservoir head
he=zeros(ndata,1);
f=zeros(ndata,2);
% for i=1:ndata
%     if(i == 1)
%         he(i)=(eff_rain(i)*delta_t+he(i))/(1+Kd*delta_t);
%         f(i,1)=Kd*he(i);
%         f(i,2)=0;
%         f(i,3)=he(i);
%     else
%         temp=he(i-1)+eff_rain(i)*delta_t;
%         if (temp > h_thre)
%             he(i)=(eff_rain(i)*delta_t+he(i-1)+Kp*h_thre*delta_t)/(1+(Kd+Kp)*delta_t);
%             f(i,1)=Kd*he(i);
%             f(i,2)=max(0,Kp*(he(i)-h_thre));
%             f(i,3)=he(i);
%         else
%             he(i)=(eff_rain(i)*delta_t+he(i-1))/(1+Kd*delta_t);
%             f(i,1)=Kd*he(i);
%             f(i,2)=0;  
%             f(i,3)=he(i);
%         end
%     end
% end
for i=1:ndata
    if(i == 1)
        he(i)=(eff_rain(i)*delta_t+he(i))/(1+Kd*delta_t);
        f(i,1)=Kd*he(i);
        f(i,2)=0;
        f(i,3)=he(i);
    else
        if (he(i-1)+eff_rain(i)*delta_t > h_thre)
            he(i)=(eff_rain(i)*delta_t+he(i-1)+Kp*h_thre*delta_t)/(1+(Kd+Kp)*delta_t);
            f(i,1)=Kd*he(i);
            f(i,2)=Kp*(he(i)-h_thre);
            f(i,3)=he(i);
            if (he(i) < h_thre)
                he(i)=(eff_rain(i)*delta_t+he(i-1))/(1+Kd*delta_t);
                f(i,1)=Kd*he(i);
                f(i,2)=0;
                f(i,3)=he(i);
            end
        else
            he(i)=(eff_rain(i)*delta_t+he(i-1))/(1+Kd*delta_t);
            f(i,1)=Kd*he(i);
            f(i,2)=0;  
            f(i,3)=he(i);
            if(he(i) > h_thre)
                he(i)=(eff_rain(i)*delta_t+he(i-1)+Kp*h_thre*delta_t)/(1+(Kd+Kp)*delta_t);
                f(i,1)=Kd*he(i);
                f(i,2)=Kp*(he(i)-h_thre);
                f(i,3)=he(i);
            end
        end
    end
end