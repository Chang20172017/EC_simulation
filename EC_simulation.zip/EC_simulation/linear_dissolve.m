function f = linear_dissolve(input_dis, input_c, waterlevel, D, A, delta_t, uplimit)

%%  input and output are the calculated discharge by the flow model
     % input(:,1) is the discharge; input(:,2) is the concentration;
     
%%  waterlevel is the water level of the reservoir
%%  D is the dissolvtion rate
%%  A is the catchment area
%%  uplimit is the upper limit of the conductivity


ndata = length(input_dis);


reser_c=zeros(ndata,1);
reser_c(1)=uplimit;
for i=2 : ndata
%    % calculate the solute mass
%    solute1=input_dis(i)*delta_t*A*(input_c(i));
%    solute2=waterlevel(i-1)*A*(reser_c(i-1)+D*delta_t);
% %    solute2=waterlevel(i-1)*A*min((reser_c(i-1)+D*delta_t), uplimit);
%    update_c=(solute1+solute2)/(input_dis(i)*delta_t*A+waterlevel(i-1)*A);
%    reser_c(i)=min(update_c, uplimit);   

% % %% new
   solute1=input_dis(i)*delta_t*A*(input_c(i));
   solute2=waterlevel(i-1)*A*reser_c(i-1);
%     solute2=waterlevel(i-1)*A*min((reser_c(i-1)+D*delta_t), uplimit);
   update_c=(solute1+solute2)/(input_dis(i)*delta_t*A+waterlevel(i-1)*A);
   reser_c(i)=min(update_c+D*delta_t, uplimit);
end
f=reser_c;