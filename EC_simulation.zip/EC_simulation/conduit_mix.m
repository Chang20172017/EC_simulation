function f  = conduit_mix(slow, fast, fast_c, Dcon, delta_t, h_old, tocon)

ndata = size(slow, 1);

conduit_c = linspace(tocon, tocon, ndata);

for i = 2 : ndata
    conduit_c(i) = (slow(i)*tocon*delta_t + fast(i) * fast_c(i)*delta_t + h_old * min(conduit_c(i-1) + Dcon * delta_t, tocon))/(slow(i)*delta_t + fast(i)*delta_t + h_old);
end

f = conduit_c;

