function f = cal_effrainfall( rainfall, weather, delta_time, S_max  )
%%% to calculate the effective rainfall recharging the following reservoir though a evapotranspirattion store 
%%%   The potential evapotranspiration is calculated by the Eagleman's
%%%   Method(1967)
%%%   two weather data are needed (humidity and temperature)
%%%   delta_time is the modelling interval time

%%% get the size of rainfall data
    ra=length(rainfall);
%%% get the size of weather data
    we=size(weather,1);
%%% judge whether the delta_time could be divided by 60
    ntime = 24.*60/delta_time;
    if (rem(ntime,1))
        error('delta_time is wrong');
    end
    ntime=fix(ntime);
    
    if(ra ~= ntime*we)
        error('the number of rainfall and weather data do not match');
    end
    
%%% calculate the potential evapotraspiration

%%% calculate c(t) and emax according to the temperature
%%% weather(:,1) is the temperature weather(:,2) is the humidity
%%% rainfall is the rain intensity
%%% during the interval time.
    ct=zeros(we,1);
    emax=zeros(we,1);
    hundred_rh=zeros(we,1);
	for i=1:we
		if (weather(i,1) < 0)
			ct(i)= 0.63;
		elseif (weather(i,1) > 21 )
			ct(i)= 1.13;
		else
			ct(i)=0.63+0.024*weather(i,1);
		end
		emax(i) = 6.1*exp(17.1*weather(i,1)/(234.2+weather(i,1)));
		hundred_rh(i) =   100-weather(i,2);
	end
	cw = 0.8;
	fi = 0.0329;
	ETp=zeros(we,1);
	for i=1:we
		ETp(i)=fi*cw*ct(i)*emax(i)*hundred_rh(i)^0.5/1000;
	end
%%% redistribute the potential evapotranspiration into each modelling time 
	ETp_di=ETp/ntime;
	step_ET=zeros(we*ntime,1);
	for i=1:we
		for j=1:ntime
			step_ET((i-1)*ntime+j)= ETp_di(i);
		end
	end
    s=zeros(ra,1);
	evp=zeros(ra,1);
	ep=zeros(ra,1);
	for i=1:ra
		evp(i)=s(i)*step_ET(i)/S_max;
		s(i)=s(i)+rainfall(i)/1000-evp(i);
		if (s(i) > S_max)
			ep(i)=s(i)-S_max;
			s(i)=S_max;
		end
		if (s(i) < 0)
			s(i) = 0;
		end
		if (i<ra)
			s(i+1)=s(i);
		end
	end
		f=ep;
		

end

