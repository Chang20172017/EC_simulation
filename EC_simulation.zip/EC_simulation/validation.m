clear; clc;
global discharge  rainfall  weather  A  delta_t tocon  


% fff1=[];
% path1='E:\matlab\conductivity_simulation\improve_model_structure';
% addpath(path1);
% load M4s2.mat;
% 
% A=1e06;       %% define the modelling area
% delta_t=15*24;
% 
% for i=11:11
%     temp=p{i,3};
%     for j=1:30
%         bestx=X(j,:);
%         aa=['TWO(i,:)=' temp '(bestx)'];
%         eval(aa);
%     end
%     
path1='E:\matlab\conductivity_simulation\improve_model_structure';
addpath(path1);
load ob1.mat;
A=1e06;       %% define the modelling area
delta_t=15*24;

aa1=[0.140824437	0.002458158	0.322870864	4.25E-06	0.083731583	0.539560035	0.00056112	0.36504989];
aa2=[0.199908775	7.35E-05	0.03308548	5.72E-06	0.002669435	0.536733568	0.000246078	0.139218038];

% fun=M1s1(aa1);
% fun=M2s2(aa2);
% fun=M3s2(aa1);
fun=M4s2(aa2);
% for i=1:11
%     fun=p{i,3};
%     aa=['other(i)=' fun '(xxx{i,1})'];
%     eval(aa);
% end

%     
% end
% load M5.mat
% % load model_82.mat
% 
% % ndata=length(rainfall);
% path1='E:\matlab\conductivity_simulation\improve_model_structure';
% addpath(path1);
% A=1e06;       %% define the modelling area
% delta_t=15*24;
% bestx=X(1,:);
% yy=M5(bestx);