function f = objective(mea, sim)

%% set negative value to zero
mea(mea < 0) = 0;
sim(sim < 0) = 0;

%% calibration
begin1 = 1579;  endd1 = 1947;
%% validation 1
begin2 = 262; endd2 = 437;
%% validation 2
begin3 = 971; endd3 = 1166;


dis = mea(:,1); EC = mea(:,2);
sidis = sim(:,1); siEC = sim(:,2);
% calibration
dis1 = dis(begin1 : endd1); sidis1 = sidis(begin1 : endd1);
EC1 = EC(begin1 : endd1); siEC1 = siEC(begin1 : endd1);
% validation1
dis2 = dis(begin2 : endd2); sidis2 = sidis(begin2 : endd2);
EC2 = EC(begin2 : endd2); siEC2 = siEC(begin2 : endd2);
% validation2
dis3 = dis(begin3 : endd3); sidis3 = sidis(begin3 : endd3);
EC3 = EC(begin3 : endd3); siEC3 = siEC(begin3 : endd3);

%% calculate squared Nash coefficient
nashd1 = NSE(sqrt(sidis1), sqrt(dis1));
nashEC1 =  NSE(sqrt(siEC1), sqrt(EC1));
r1 = corr(EC1, siEC1, 'type', 'Pearson');



nashd2 = NSE(sqrt(sidis2), sqrt(dis2));
nashEC2 =  NSE(sqrt(siEC2), sqrt(EC2));
r2 = corr(EC2, siEC2, 'type', 'Pearson');


nashd3 = NSE(sqrt(sidis3), sqrt(dis3));
nashEC3 =  NSE(sqrt(siEC3), sqrt(EC3));
r3 = corr(EC3, siEC3, 'type', 'Pearson');


f = [nashd1, nashEC1, r1,  nashd2, nashEC2, r2, nashd3, nashEC3, r3];

