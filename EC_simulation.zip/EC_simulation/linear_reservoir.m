function f=linear_reservoir(eff_rain, Kd,delta_t)
%% this function is used to calculate the outflow of the linear reservoir
%% eff_rain is the input(effective rainfall), rainfall intensity
%% Kd is the reservoir coefficient
%% delta_t is the time_step

%% output f is the outflow of the reservoir
%acquire the data number
ndata=length(eff_rain);
%intialize the reservoir head
he=linspace(0,0,ndata);
f=zeros(ndata,1);
for i=1:ndata
    if(i == 1)
        he(i)=(eff_rain(i)*delta_t+he(i))/(1.0+Kd*delta_t);
        f(i,1)=Kd*he(i);
        f(i,2)=he(i);
    else
        he(i)=(eff_rain(i)*delta_t+he(i-1))/(1.0+Kd*delta_t);
        f(i,1)=Kd*he(i);
        f(i,2)=he(i);
    end
end

