function f=M2(parameters, varargin)
global rainfall weather delta_t discharge  A   tocon

smax=parameters(1); ks=parameters(2); kf=parameters(3); h1=parameters(4); D=parameters(5); h_old=parameters(6);

h_old=0;
%%  calculate the spring discharge
% calculate the effective rainfall
eff_rain=cal_effrainfall(rainfall, weather, delta_t, smax);
eff_rain=eff_rain/delta_t;
ndata=length(eff_rain);


% calculate the slow reservoir
slow=epikarst_reservoir(eff_rain, ks, h1, delta_t);

% calculate the fast reservoir
fast=linear_reservoir(slow(:,1), kf, delta_t);


% calculate the spring discharge
si_discharge=(slow(:,2)+fast(:,1))*A/60;

%% calculate the spring conductivity
in_c=zeros(ndata,1);


% calculate the conductivity in fast reservoir
fast_con=linear_dissolve_mix(slow(:,1), in_c, fast(:,2), D, A, delta_t, h_old, tocon);

% assume the conductivity in slow reservoir always equal to the balanced
% value
slow_con=linspace(tocon,tocon,ndata);

% the spring conductivity is the mix of slow and fast reservoir
spring_con=two_mix(slow(:,2), slow_con, fast(:,1), fast_con);

%% calculate the objectives
mea=discharge; sim(:,1)=si_discharge; sim(:,2)=spring_con;
f=objective_value1(mea,sim);


