function f=M4(var, parameters, varargin)
% global discharge EC rainfall weather A delta_t tocon rainEC

smax=parameters(1); ks=parameters(2); h1=parameters(3);  kf=parameters(4); 
Depi=parameters(5); Df=parameters(6);  v_old=parameters(7);  tocon = parameters(8);

 discharge = var{1};  EC = var{2};  rainfall = var{3};  weather = var{4};  A = var{5} ; 
 delta_t = var{6};   rainEC = var{7};

% discharge = varr{1}; EC = varr{2}; rainfall = varr{3}; weather = varr{4};
% A = varr{5};  delta_t = varr{6}; tocon = varr{7};
% h_old = 0;
%%  calculate the spring discharge
% calculate the effective rainfall
eff_rain=cal_effrainfall(rainfall, weather, delta_t, smax);
eff_rain=eff_rain/delta_t;
ndata=length(eff_rain);

% lag recharge
% eff_rain=lag_recharge(eff_rain, 1);

% calculate the discharge of epikarst
ff=epikarst_reservoir(eff_rain, ks, h1, delta_t);


% calculate the discharge of fast reservoir
fast = linear_reservoir(ff(:,1)+ff(:,2), kf, delta_t);


si_discharge=fast(:,1)*A/60;

%% calculate the spring conductivity
% considering the lag time for dissolution
in_c=linspace(rainEC, rainEC, ndata);
% in_c(:)=Depi*delta_t;

% calculate the conductivity in epikarst reservoir
epi_con=linear_dissolve(eff_rain, in_c, ff(:,3), Depi, A, delta_t, tocon);


for i=1:ndata
    in_slow=ff(:,2);
    in_fast=ff(:,1);
    in_fastcon(i)= (in_slow(i)*tocon+in_fast(i)*epi_con(i))/(in_slow(i)+in_fast(i));
end

% calculate the conductivity in fast reservoir
fast_con=linear_dissolve_mix(in_slow+in_fast, in_fastcon, fast(:,2), Df, A, delta_t,v_old, tocon);


spring_con=fast_con;

%% calculate the objectives
mea(:,1) = discharge; mea(:,2) = EC;
sim(:,1) = si_discharge; sim(:,2)=spring_con; 
f=objective(mea,sim);



