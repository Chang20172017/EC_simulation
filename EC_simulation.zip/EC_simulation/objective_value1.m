function f = objective_value1( measured, simulated )
%%%% calculate the objective values according to the measured and simulated discharge data
%%  contains three objectives
%%% get the number of series data
    sim_dis=simulated(:,1);
    sim_con=simulated(:,2);
    mea_dis=measured(:,1);
    mea_con=measured(:,2);
    
    initial_n1=500;
    initial_n2=523;
    f(1)=nash(sqrt(mea_dis(initial_n1:end)), sqrt(sim_dis(initial_n1:end)));
    f(2)=nash(sqrt(abs(446.6-(mea_con(initial_n2:end)))), sqrt(abs(446.6-(sim_con(initial_n2:end)))));


%      f(2)=nash(abs(446.6-(mea_con(initial_n2:end))), abs(446.6-(sim_con(initial_n2:end))));
%      f(2)=f(1)+f(2);
%     f(2)=0.2;
%     sum=0;
%     for i=initial_n2:length(sim_con)
%         sum=sum+(mea_con(i)-sim_con(i))^2;
%     end
%     f(2)=sqrt(sum/(length(sim_con)-initial_n2+1));
% 
% f=(f(1)+f(2))/2;
% f=f(2);
%     

