function f = linear_dissolve_mix(input_dis, input_c, waterlevel, D, A, delta_t, deep, uplimit)

%%  input and output are the calculated discharge by the flow model
     % input(:,1) is the discharge; input(:,2) is the concentration;
     
%%  waterlevel is the water level of the reservoir
%%  D is the dissolvtion rate
%%  A is the catchment area
%%  uplimit is the upper limit of the conductivity


ndata = length(input_dis);


reser_c=zeros(ndata,1);
reser_c(1)=uplimit;
for i=2 : ndata
   %% calculate the solute mass
%    final_w=waterlevel(i-1)+deep;
%    solute1=input_dis(i)*delta_t*A*(input_c(i)+D*delta_t/2);
%    solute2=final_w*A*min((reser_c(i-1)+D*delta_t), uplimit);
% 
%    update_c=(solute1+solute2)/(input_dis(i)*delta_t*A+final_w*A);
%% new
%    final_w=waterlevel(i-1)+deep;
%    solute1=input_dis(i)*delta_t*A*min(input_c(i)+D*delta_t, uplimit);
%    solute2=final_w*A*min(reser_c(i-1)+D*delta_t, uplimit);
% 
%    update_c=(solute1+solute2)/(input_dis(i)*delta_t*A+final_w*A);    
% 
% %    reser_c(i)=min(update_c+D*delta_t, uplimit);
%     reser_c(i) = update_c;

%%%%%%%%%%%%%%%%%%%%%%%
   final_w=waterlevel(i-1)+deep;
   solute1=input_dis(i)*delta_t*A*input_c(i);
   solute2=final_w*A*reser_c(i-1);

   update_c=(solute1+solute2)/(input_dis(i)*delta_t*A+final_w*A);    

   reser_c(i)=min(update_c+D*delta_t, uplimit);
%     reser_c(i) = update_c;


end
f=reser_c;