function f=epikarst_reservoir(input, kd, h1, delta_t)
%% This function calculate the output of a epikarst reservoir in MODEL M1
% input is the recharge on the reservoir, Kd is the reservoir coefficient
% of lower outlet, h1 is the threshold value for the quick reservoir,
% delta_t is the time step

ndata = length(input);

reserh = zeros(ndata,1);
slowoutput=zeros(ndata,1);
quickoutput=zeros(ndata,1);

for i = 2 : ndata
    h_temp = reserh(i-1)+input(i)*delta_t;
    if h_temp <= h1;
        reserh(i)= (input(i)*delta_t+reserh(i-1))/(1+kd*delta_t);
        slowoutput(i)=reserh(i)*kd;
        quickoutput(i)=0;
    else
        quickoutput(i) = (h_temp-h1)/delta_t;
        reserh(i) = h1/(1+kd*delta_t);
        slowoutput(i) = reserh(i)*kd;
    end
end
f(:,1)=quickoutput;
f(:,2)=slowoutput;
f(:,3)=reserh;