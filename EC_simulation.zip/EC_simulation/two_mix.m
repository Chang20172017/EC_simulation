function f=two_mix(fast, fast_con, slow, slow_con)

ndata=length(fast);

final=zeros(ndata,1);

for i=1:ndata
    solute=fast(i)*fast_con(i)+slow(i)*slow_con(i);
    volume=fast(i)+slow(i);
    if volume == 0
        final(i) = slow_con(i);
    else
        final(i)=solute/volume;
    end
end

f=final;