clear; clc;
path = pwd;
addpath(genpath(path));
global discharge EC rainfall weather A delta_t  rainEC

%% read input data(time step = 12 hours)
load inputdata_12hour.mat;

A = 1.09e06;
delta_t = 60*12;
rainEC = 9.3;
varr = {};
var{1} = discharge; var{2} = EC; var{3} = rainfall; var{4} = weather; 
var{5} = 1e06;  var{6} = 60*12;  var{7} = rainEC;

%% calibration

p ={};
%% before
p{1,1} = [0, 1e-05, 5e-04, 0, 0, 460]; p{1,2} = [0.1, 1e-03, 1e-02, 0.04, 0.65, 510]; p{1,3} = ['smax', 'ks', 'kf', 'h1', 'Df']; p{1,4} = 'M1';
p{3,1} = [0, 1e-05, 5e-04 0, 0, 0, 460]; p{3,2} = [0.1, 1e-03, 1e-02, 0.04, 0.65, 0.4, 510]; p{3,3} = ['smax', 'ks', 'kf', 'h1', 'D', 'Vold']; p{3,4} = 'M2';
p{4,1} = [0, 1e-05, 5e-04, 0, 0, 0, 460]; p{4,2} = [0.1, 1e-03, 1e-02, 0.04, 0.65, 0.4, 510]; p{4,3} = ['smax', 'ks', 'kf', 'h1', 'Df', 'Vold']; p{4,4} = 'M3';
p{8,1} = [0, 1e-05, 0, 5e-04, 0, 1e-04, 0, 460]; p{8,2} = [0.1, 1e-03, 0.04, 1e-02, 0.65, 1e-02, 0.4, 510]; p{8,3} = ['smax', 'ks', 'h1', 'kf', 'Depi', 'Df', 'Vold']; p{8,4} = 'M4';



%%   the used functions belong to SAFE TOOLBOX( University of Bristol) which is
%%   available upon request from Francesca Pianosi(francesca.pianosi@bristol.ac.uk)
%%   Reference: Pianosi, F., Sarrazin, F., Wagener, T., 2015. A Matlab toolbox for Global Sensitivity Analysis. Environmental Modelling & Software, 70: 80-85.
for m = 1 : 4
    i =  in(m);
    matlabpool open local 8;
    myfun = p{i,4};
    SampStrategy = 'lhs';
    N = 1000000;
    DistrFun = 'unif';
    lb = p{i,1}; ub = p{i,2};
    DistrPar = cell(length(lb));
    for j = 1 : length(lb)
        DistrPar{j} = [lb(j), ub(j)];
    end
    M = length(lb);
    X = AAT_sampling(SampStrategy, M, DistrFun, DistrPar, N);
    %% run the model
    Y = model_evaluation( myfun, var, X);
    ss = ['save ' p{i,4}];
    matlabpool close;
    eval(ss);
end


    
    



